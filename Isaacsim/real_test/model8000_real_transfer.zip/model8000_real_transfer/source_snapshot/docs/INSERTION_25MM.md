> 2026-09-29：已按真机修复两指等量耦合，旧独立夹指假设不再适用。新物理模型与噪声说明见 [COUPLED_GRIPPER_AND_NOISE.md](COUPLED_GRIPPER_AND_NOISE.md)；旧检查点性能不能直接沿用，旧pilot入口会因配置变化拒绝执行。

# 当前任务：插入25毫米后松爪（2026-09-28）

本页覆盖旧文档中“46–48毫米才算插入成功”、10秒最大回合、成功后持续夹紧以及28/52维观测的说明。变化来自用户明确的遥操作任务定义，不是论文原始设置。

## 成功、释放与结束

1. 实际轴底低于目标孔口至少25毫米，即达到插入深度目标。不再要求XY≤0.5毫米或倾角≤5°；这两个量继续作为诊断记录。
2. 为排除孔外掉落，轴底XY需处于目标孔区域（半径13毫米，来自约26毫米孔径）；深度不能超过原越界下界57毫米。这是目标区域检查，不是精密对中门槛。
3. 达到目标后，下一个15 Hz控制步开始松爪，无额外成功持续时间要求。停止下压、保持当前TCP位置/yaw，手指持续开到60毫米；此之前仍持续−20 N闭合。释放是唯一主动停止夹紧的阶段。
4. 释放后观察2秒，以`release_complete`结束回合；若提前出现原越界条件则仍失败。释放阶段免除夹宽失败，因为开爪是预期动作。最大回合20秒（300控制步），超时自动reset。
5. 松爪后是否维持25毫米插入、是否达到47±1毫米深度、是否还满足旧严格落座条件，分别记录，不能混用。

仿真释放触发使用真实轴底几何，属于任务监督。策略没有获得真实轴位姿，但自动释放门槛有仿真特权信息，不能称为已可部署；真机应接入独立深度估计或操作者确认。没有将轴焊接、瞬移、强制两指对称或在线消除抓取误差。

## 观测、奖励与旧检查点

原28/52维基础上增加1维`releasing`标志，现在actor29、critic53，动作仍5维。释放期间策略运动指令不再推动机械臂，饱和率排除该阶段。旧24/48、28/52检查点均不能直接续训；新目录为`logs/rsl_rl/forge_shaft_insert_release25/`。

`inserted`和`prediction`使用新的25毫米几何目标；keypoint目标深度也改为25毫米。奖励权重没有再增大。名义下插轨迹仍允许向47毫米推进，但一旦满足释放条件即停止下压。新旧reward数值和成功率因任务定义不同，不应直接比较。

## 为什么之前没有成功

旧47±1毫米判据、零残差、只把10秒延长为20秒的对照中，4/4回合曾完整到位，4/4连续成功至少0.5秒，2/4结束时仍严格成功。首次完整到位出现在10.73–11.73秒，超过旧10秒窗口；末期另2回合XY约0.505/0.599毫米而超过旧0.5毫米阈值。

所以不是完全插不进去。时间不足和末期严格对中判据都影响旧结果；继续强夹下压也不是保持成功的合适方式。此数据在`outputs/insertion_completion/time20.csv`与`time20_analysis.json`，仍属于旧判据，不能混成新的释放成功率。

最终25毫米释放测试结果另记于实验变更记录和`outputs/insertion_completion/release25_depth_only*`。

## 检查指令

先看零残差GUI，检查25毫米时是否停止下压、开爪并落座：

```bash
cd /home/masais/Xinyu/Isaacsim
export FORGE_PY=/home/masais/miniconda3/envs/Xinyu_isaacsim/bin/python
"$FORGE_PY" FORGE_shaft_Insert/scripts/paper_smoke_test.py --mode directed --nominal --num_envs 4 --steps 310 --metrics_csv FORGE_shaft_Insert/outputs/manual_release25/nominal.csv
```

每次另用输出文件名，避免覆盖。去掉`--nominal`则保留抓取x±8/z±5毫米、孔估计xyz±10毫米等误差。`--no_release`只用于诊断持续夹持，与正式释放任务不同。

之后从新模型做20轮GUI检查：

```bash
"$FORGE_PY" FORGE_shaft_Insert/scripts/train.py --task FORGE-Shaft-Insert-Paper-v0 --num_envs 4 --max_iterations 20 --run_name release25_gui agent.algorithm.num_mini_batches=2
```

零残差成功说明物理与控制流程存在可行路径，不保证带随机误差的PPO一定收敛。看独立回合的25毫米成功率、释放完成率、最终深度、接触力、越界/夹宽失败与轨迹；20轮主要检查训练行为。对奖励漏洞、随机误差下搜索效率和真机释放判断仍需后续验证。


## 最终实测结果

4环境、310控制步、零残差、无抓取/孔估计误差。完成6回合（首轮4+重复2），另2回合在测试停止时未结束、不计分母。6/6达到25 mm、释放后保持成功且真实落座；严格旧落座诊断也6/6。终局深度46.989–46.996 mm，完成用时9.20–11.40秒，0超时/越界/夹宽失败，全程采样接触峰值4.468 N，完成回合平均P95为1.506 N。松爪前最大夹持相对漂移6.562 mm；保留物理滑移，没有强制纠偏。数据在`outputs/insertion_completion/release25_depth_only.csv`、对应control_trace、run快照及summary.json。

这是零残差物理流程的成功案例，不是PPO学到的成功率，也不是随机误差下的泛化率。最终版本取消精密对中/倾角释放门槛；没有通过改变物理深度或传送零件制造落座。短PPO兼容性测试另记。

新任务PPO集成检查通过：4环境、2mini-batch、2轮、256样本，训练44.97秒，退出码0。运行`logs/rsl_rl/forge_shaft_insert_release25/2026-09-28_15-13-39_release25_integration_check`已保存检查点、配置、源码快照、控制轨迹与TB scalar导出。验证actor29/critic53及20秒回合兼容训练，不构成收敛或随机误差成功率验证。
